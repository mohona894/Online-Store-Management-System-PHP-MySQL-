<?php
	require('connection.php');
	require('myfunction.php');
	session_start();

	$user_first_name = $_SESSION['user_first_name'];
	$user_last_name = $_SESSION['user_last_name'];

	if (!empty($user_first_name) && !empty($user_last_name)) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<title>Edit Store Product</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
	<style>
		body {
			background-color: #f8fafc;
			font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
		}
		.container-edit {
			padding: 30px 40px;
			background: #fff;
			border-radius: 12px;
			box-shadow: 0 10px 20px rgba(0,0,0,0.08);
			margin: 30px 0 60px;
		}
		h3 {
			color: #198754;
			font-weight: 700;
			margin-bottom: 30px;
		}
		label {
			font-weight: 600;
			color: #333;
		}
		.form-control, .form-select {
			border-radius: 8px;
			border: 1.5px solid #ced4da;
			transition: border-color 0.3s ease;
			box-shadow: none;
		}
		.form-control:focus, .form-select:focus {
			border-color: #198754;
			box-shadow: 0 0 5px rgba(25, 135, 84, 0.4);
		}
		.btn-success {
			min-width: 110px;
			font-weight: 600;
			padding: 10px 18px;
			border-radius: 8px;
		}
		.btn-secondary {
			border-radius: 8px;
		}
		.alert {
			border-radius: 8px;
			font-weight: 600;
		}
	</style>
</head>
<body>
	<div class="container bg-light">
		<div class="container-foulid border-bottom border-success">
			<?php include('topbar.php'); ?>
		</div>

		<div class="container-foulid">
			<div class="row">
				<div class="col-sm-3 bg-light p-0 m-0">
					<?php include('leftbar.php'); ?>
				</div>

				<div class="col-sm-9 border-start border-success">
					<div class="container-edit">
						<h3><i class="fas fa-store me-2"></i>Edit Store Product</h3>

						<?php
							if(isset($_GET['id'])){
								$getid = intval($_GET['id']);
								$sql = "SELECT * FROM store_product WHERE store_product_id = $getid";
								$query = $conn->query($sql);
								$data = mysqli_fetch_assoc($query);

								$store_product_id = $data['store_product_id'];
								$store_product_name = $data['store_product_name'];
								$store_product_quentity = $data['store_product_quentity'];
								$store_product_entry_date = $data['store_product_entry_date'];
							}

							if(isset($_GET['store_product_name'])){
								$new_store_product_name = $_GET['store_product_name'];
								$new_store_product_quentity = $_GET['store_product_quentity'];
								$new_store_product_entry_date = $_GET['store_product_entry_date'];
								$new_store_product_id = intval($_GET['store_product_id']);

								$sql1 = "UPDATE store_product SET 
											store_product_name = '$new_store_product_name',
											store_product_quentity = '$new_store_product_quentity',
											store_product_entry_date = '$new_store_product_entry_date'
											WHERE store_product_id = $new_store_product_id";

								if($conn->query($sql1) === TRUE){
									echo '<div class="alert alert-success">Update Successful!</div>';
								} else {
									echo '<div class="alert alert-danger">Error updating record: ' . $conn->error . '</div>';
								}

								// Refresh data to show updated values in form
								$store_product_id = $new_store_product_id;
								$store_product_name = $new_store_product_name;
								$store_product_quentity = $new_store_product_quentity;
								$store_product_entry_date = $new_store_product_entry_date;
							}
						?>

						<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="GET" class="needs-validation" novalidate>
							<div class="mb-3">
								<label for="store_product_name" class="form-label">Product:</label>
								<select name="store_product_name" id="store_product_name" class="form-select" required>
									<option value="" disabled>Select a product</option>
									<?php
										$sql = "SELECT * FROM product";
										$query = $conn->query($sql);
										while ($data = mysqli_fetch_assoc($query)) {
											$data_id = $data['prdouct_id'];
											$data_name = $data['product_name'];
											$selected = ($store_product_name == $data_id) ? 'selected' : '';
											echo "<option value='$data_id' $selected>$data_name</option>";
										}
									?>
								</select>
								<div class="invalid-feedback">Please select a product.</div>
							</div>

							<div class="mb-3">
								<label for="store_product_quentity" class="form-label">Product Quantity:</label>
								<input type="number" name="store_product_quentity" id="store_product_quentity" class="form-control" value="<?php echo htmlspecialchars($store_product_quentity ?? ''); ?>" required min="1" />
								<div class="invalid-feedback">Please enter a valid quantity (1 or more).</div>
							</div>

							<div class="mb-3">
								<label for="store_product_entry_date" class="form-label">Store Entry Date:</label>
								<input type="date" name="store_product_entry_date" id="store_product_entry_date" class="form-control" value="<?php echo htmlspecialchars($store_product_entry_date ?? ''); ?>" required />
								<div class="invalid-feedback">Please enter a valid date.</div>
							</div>

							<input type="hidden" name="store_product_id" value="<?php echo htmlspecialchars($store_product_id ?? ''); ?>" />

							<button type="submit" class="btn btn-success"><i class="fas fa-save me-1"></i> Update</button>
							<a href="list_of_entry_product.php" class="btn btn-secondary ms-2"><i class="fas fa-arrow-left me-1"></i> Back to List</a>
						</form>
					</div><!-- container-edit end -->
				</div><!-- col-sm-9 end -->
			</div><!-- row end -->
		</div><!-- container-foulid end -->

		<div class="container-foulid border-top border-success mt-4 pt-3">
			<?php include('bottombar.php'); ?>
		</div>
	</div><!-- container end -->

	<script>
		// Bootstrap form validation
		(() => {
			'use strict'
			const forms = document.querySelectorAll('.needs-validation')
			Array.from(forms).forEach(form => {
				form.addEventListener('submit', event => {
					if (!form.checkValidity()) {
						event.preventDefault()
						event.stopPropagation()
					}
					form.classList.add('was-validated')
				}, false)
			})
		})()
	</script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
	} else {
		header('location:login.php');
		exit;
	}
?>
