<?php
	require('connection.php');
	session_start();

	$user_first_name = $_SESSION['user_first_name'];
	$user_last_name = $_SESSION['user_last_name'];

	if(!empty($user_first_name) && !empty($user_last_name) ){
?>

<!DOCTYPE html>
<html>
<head>
	<title>Delete User</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>
</head>
<body>
	<div class="container bg-light">
		<div class="container-foulid border-bottom border-success">
			<?php include('topbar.php'); ?>
		</div>

		<div class="container-foulid">
			<div class="row">
				<div class="col-sm-3 bg-light p-0 m-0">
					<?php include('leftbar.php'); ?>
				</div>

				<div class="col-sm-9 border-start border-success">
					<div class="container p-4 m-4">
						<h3 class="mb-4 text-danger">Delete User</h3>

						<?php
							if(isset($_GET['id'])){
								$delete_id = intval($_GET['id']);

								$sql = "DELETE FROM users WHERE user_id = $delete_id";
								
								if($conn->query($sql) === TRUE){
									echo '<div class="alert alert-success">User deleted successfully!</div>';
								} else {
									echo '<div class="alert alert-danger">Error deleting user: ' . $conn->error . '</div>';
								}
							} else {
								echo '<div class="alert alert-warning">No user selected for deletion.</div>';
							}
						?>
						<a href="list_of_users.php" class="btn btn-secondary mt-3">Back to User List</a>
					</div>
				</div>
			</div>
		</div>

		<div class="container-foulid border-top border-success">
			<?php include('bottombar.php'); ?>
		</div>
	</div>
</body>
</html>

<?php
	}else{
		header('location:login.php');
	}
?>
