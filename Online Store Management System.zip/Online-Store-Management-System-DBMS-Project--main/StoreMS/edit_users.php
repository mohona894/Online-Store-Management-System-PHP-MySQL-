<?php
	require('connection.php');
	session_start();

	$user_first_name = $_SESSION['user_first_name'];
	$user_last_name = $_SESSION['user_last_name'];

	if(!empty($user_first_name) && !empty($user_last_name) ){
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<title>Edit User</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
	<style>
		body {
			background-color: #f8fafc;
			font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
		}
		.container-edit {
			background: #fff;
			padding: 30px 40px;
			border-radius: 12px;
			box-shadow: 0 10px 20px rgba(0,0,0,0.08);
			margin: 30px 0 60px;
		}
		h3 {
			color: #198754; /* Bootstrap success green */
			font-weight: 700;
			margin-bottom: 30px;
		}
		label {
			font-weight: 600;
			color: #333;
		}
		.form-control {
			border-radius: 8px;
			border: 1.5px solid #ced4da;
			transition: border-color 0.3s ease;
			box-shadow: none;
		}
		.form-control:focus {
			border-color: #198754;
			box-shadow: 0 0 5px rgba(25, 135, 84, 0.4);
		}
		.btn-success {
			min-width: 130px;
			font-weight: 600;
			padding: 10px 18px;
			border-radius: 8px;
		}
		.alert {
			border-radius: 8px;
			font-weight: 600;
		}
	</style>
</head>
<body>
	<div class="container bg-light">
		<div class="container-foulid border-bottom border-success">
			<?php include('topbar.php'); ?>
		</div>

		<div class="container-foulid">
			<div class="row">
				<div class="col-sm-3 bg-light p-0 m-0">
					<?php include('leftbar.php'); ?>
				</div>

				<div class="col-sm-9 border-start border-success">
					<div class="container-edit">
						<h3><i class="fas fa-user-edit me-2"></i>Edit User</h3>

						<?php
							if(isset($_GET['id'])){
								$getid = intval($_GET['id']);
								$sql = "SELECT * FROM users WHERE user_id=$getid";
								$query = $conn->query($sql);
								$data = mysqli_fetch_assoc($query);

								$user_id 			= $data['user_id'];
								$user_first_name_db = $data['user_first_name'];
								$user_last_name_db  = $data['user_last_name'];
								$user_email 		= $data['user_email'];
								$user_password 		= $data['user_password'];
							}

							if(isset($_GET['user_first_name'])){
								$new_user_first_name 	= trim($_GET['user_first_name']);
								$new_user_last_name 	= trim($_GET['user_last_name']);
								$new_user_email 		= trim($_GET['user_email']);
								$new_user_password 		= trim($_GET['user_password']);
								$new_user_id 			= intval($_GET['user_id']);

								$sql1 = "UPDATE users SET 
											user_first_name=?, 
											user_last_name=?, 
											user_email=?, 
											user_password=?
											WHERE user_id = ?";
								$stmt = $conn->prepare($sql1);
								$stmt->bind_param('ssssi', $new_user_first_name, $new_user_last_name, $new_user_email, $new_user_password, $new_user_id);

								if($stmt->execute()){
									echo '<div class="alert alert-success">Update Successful!</div>';
									// Refresh data after update
									$user_first_name_db = $new_user_first_name;
									$user_last_name_db  = $new_user_last_name;
									$user_email 		= $new_user_email;
									$user_password 		= $new_user_password;
								} else {
									echo '<div class="alert alert-danger">Error updating record: ' . htmlspecialchars($stmt->error) . '</div>';
								}
								$stmt->close();
							}
						?>

						<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="GET" class="needs-validation" novalidate>
							<div class="mb-3">
								<label for="user_first_name" class="form-label">User's First Name:</label>
								<input type="text" id="user_first_name" name="user_first_name" value="<?php echo htmlspecialchars($user_first_name_db ?? ''); ?>" class="form-control" required>
								<div class="invalid-feedback">Please enter the first name.</div>
							</div>

							<div class="mb-3">
								<label for="user_last_name" class="form-label">User's Last Name:</label>
								<input type="text" id="user_last_name" name="user_last_name" value="<?php echo htmlspecialchars($user_last_name_db ?? ''); ?>" class="form-control" required>
								<div class="invalid-feedback">Please enter the last name.</div>
							</div>

							<div class="mb-3">
								<label for="user_email" class="form-label">User's Email:</label>
								<input type="email" id="user_email" name="user_email" value="<?php echo htmlspecialchars($user_email ?? ''); ?>" class="form-control" required>
								<div class="invalid-feedback">Please enter a valid email address.</div>
							</div>

							<div class="mb-3">
								<label for="user_password" class="form-label">User's Password:</label>
								<input type="password" id="user_password" name="user_password" value="<?php echo htmlspecialchars($user_password ?? ''); ?>" class="form-control" required>
								<div class="invalid-feedback">Please enter a password.</div>
							</div>

							<input type="hidden" name="user_id" value="<?php echo htmlspecialchars($user_id ?? ''); ?>">

							<button type="submit" class="btn btn-success"><i class="fas fa-save me-1"></i> Update User</button>
						</form>
					</div><!-- container-edit end -->
				</div><!-- col-sm-9 end -->
			</div><!-- row end -->
		</div><!-- container-foulid end -->

		<div class="container-foulid border-top border-success mt-4 pt-3">
			<?php include('bottombar.php'); ?>
		</div>
	</div><!-- container end -->

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
	<script>
		(() => {
			'use strict';
			const forms = document.querySelectorAll('.needs-validation');
			Array.from(forms).forEach(form => {
				form.addEventListener('submit', event => {
					if (!form.checkValidity()) {
						event.preventDefault();
						event.stopPropagation();
					}
					form.classList.add('was-validated');
				}, false);
			});
		})();
	</script>
</body>
</html>

<?php
	}else{
		header('location:login.php');
		exit;
	}
?>
