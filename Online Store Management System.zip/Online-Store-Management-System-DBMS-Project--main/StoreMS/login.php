<?php
	require('connection.php');
	session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<title>Login - Store Management System</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" />
	<style>
		body {
			background: #f8f9fa;
			height: 100vh;
			display: flex;
			align-items: center;
			justify-content: center;
		}
		.login-card {
			max-width: 400px;
			width: 100%;
			padding: 2rem;
			border-radius: 0.5rem;
			box-shadow: 0 0 15px rgba(0,0,0,0.1);
			background-color: #fff;
		}
		.logo {
			font-size: 2rem;
			font-weight: 700;
			color: #198754;
			text-align: center;
			margin-bottom: 1.5rem;
			letter-spacing: 2px;
		}
	</style>
</head>
<body>
	<div class="login-card">
		<div class="logo">STORE MANAGEMENT</div>

		<?php
		if (isset($_POST['user_email'])) {
			$user_email = trim($_POST['user_email']);
			$user_password = trim($_POST['user_password']);

			// Simple escaping to avoid SQL injection - ideally use prepared statements!
			$user_email_escaped = mysqli_real_escape_string($conn, $user_email);
			$user_password_escaped = mysqli_real_escape_string($conn, $user_password);

			$sql = "SELECT * FROM users WHERE user_email='$user_email_escaped' AND user_password='$user_password_escaped'";
			$query = $conn->query($sql);

			if ($query && mysqli_num_rows($query) > 0) {
				$data = mysqli_fetch_assoc($query);

				$_SESSION['user_first_name'] = $data['user_first_name'];
				$_SESSION['user_last_name'] = $data['user_last_name'];

				header('Location: index.php');
				exit;
			} else {
				echo '<div class="alert alert-danger" role="alert">Invalid email or password.</div>';
			}
		}
		?>

		<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST" novalidate>
			<div class="mb-3">
				<label for="user_email" class="form-label">Email address</label>
				<input type="email" class="form-control" id="user_email" name="user_email" placeholder="name@example.com" required>
				<div class="invalid-feedback">
					Please enter a valid email address.
				</div>
			</div>

			<div class="mb-3">
				<label for="user_password" class="form-label">Password</label>
				<input type="password" class="form-control" id="user_password" name="user_password" required minlength="6" placeholder="Your password">
				<div class="invalid-feedback">
					Please enter your password (min 6 characters).
				</div>
			</div>

			<button type="submit" class="btn btn-success w-100">Login</button>
		</form>
	</div>

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
	<script>
		// Bootstrap form validation script
		(() => {
			'use strict'
			const forms = document.querySelectorAll('form')

			Array.from(forms).forEach(form => {
				form.addEventListener('submit', event => {
					if (!form.checkValidity()) {
						event.preventDefault()
						event.stopPropagation()
					}
					form.classList.add('was-validated')
				}, false)
			})
		})()
	</script>
</body>
</html>
