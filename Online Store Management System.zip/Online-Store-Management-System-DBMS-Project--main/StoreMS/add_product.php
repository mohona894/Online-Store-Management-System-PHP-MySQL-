<?php
require('connection.php');
session_start();

$user_first_name = $_SESSION['user_first_name'] ?? '';
$user_last_name  = $_SESSION['user_last_name'] ?? '';

if (!empty($user_first_name) && !empty($user_last_name)) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<title>Add Product</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
	<style>
		body {
			background: linear-gradient(to right, #e9f5ef, #f0fff0);
			min-height: 100vh;
		}
		.card {
			border-radius: 1rem;
			box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
		}
		.card-header {
			background-color: #198754;
			color: white;
			font-weight: bold;
			border-radius: 1rem 1rem 0 0;
		}
	</style>
</head>
<body>
	<div class="container bg-light mt-4 rounded shadow-sm p-3">
		<!-- Topbar -->
		<div class="border-bottom border-success mb-4">
			<?php include('topbar.php'); ?>
		</div>

		<div class="row">
			<!-- Sidebar -->
			<div class="col-md-3">
				<?php include('leftbar.php'); ?>
			</div>

			<!-- Main Content -->
			<div class="col-md-9 border-start border-success ps-4">
				<div class="card mb-4">
					<div class="card-header">
						<i class="fas fa-box-open me-2"></i>Add New Product
					</div>
					<div class="card-body">
						<?php
						if (isset($_GET['product_name'])) {
							$product_name = trim($_GET['product_name']);
							$product_category = $_GET['product_category'];
							$product_code = trim($_GET['prdouct_code']);
							$product_entry_date = $_GET['prdocut_entry_date'];

							if (!empty($product_name) && !empty($product_code) && !empty($product_entry_date)) {
								$sql = "INSERT INTO product (product_name, product_category, prdouct_code, prdocut_entry_date) 
										VALUES (?, ?, ?, ?)";
								$stmt = $conn->prepare($sql);
								$stmt->bind_param("siss", $product_name, $product_category, $product_code, $product_entry_date);

								if ($stmt->execute()) {
									echo '<div class="alert alert-success"><i class="fas fa-check-circle me-2"></i>Product Inserted Successfully!</div>';
								} else {
									echo '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Product Not Inserted!</div>';
								}
								$stmt->close();
							} else {
								echo '<div class="alert alert-warning"><i class="fas fa-info-circle me-2"></i>All fields are required.</div>';
							}
						}

						// Fetch categories
						$sql = "SELECT * FROM category";
						$query = $conn->query($sql);
						?>
						<form action="add_product.php" method="GET" class="needs-validation" novalidate>
							<div class="mb-3">
								<label class="form-label">Product Name</label>
								<input type="text" name="product_name" class="form-control" required>
								<div class="invalid-feedback">Please enter product name.</div>
							</div>

							<div class="mb-3">
								<label class="form-label">Product Category</label>
								<select name="product_category" class="form-select" required>
									<option value="" disabled selected>Select Category</option>
									<?php
									while ($data = mysqli_fetch_assoc($query)) {
										$category_id = $data['category_id'];
										$category_name = htmlspecialchars($data['category_name']);
										echo "<option value='$category_id'>$category_name</option>";
									}
									?>
								</select>
								<div class="invalid-feedback">Please select a category.</div>
							</div>

							<div class="mb-3">
								<label class="form-label">Product Code</label>
								<input type="text" name="prdouct_code" class="form-control" required>
								<div class="invalid-feedback">Please enter product code.</div>
							</div>

							<div class="mb-3">
								<label class="form-label">Product Entry Date</label>
								<input type="date" name="prdocut_entry_date" class="form-control" required>
								<div class="invalid-feedback">Please select entry date.</div>
							</div>

							<button type="submit" class="btn btn-success"><i class="fas fa-save me-2"></i>Submit</button>
							<a href="list_of_product.php" class="btn btn-secondary ms-2"><i class="fas fa-arrow-left me-2"></i>Back to List</a>
						</form>
					</div>
				</div>
			</div>
		</div>

		<!-- Bottombar -->
		<div class="mt-4 border-top border-success pt-3 text-center">
			<?php include('bottombar.php'); ?>
		</div>
	</div>

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
	<script>
		(() => {
			'use strict';
			const forms = document.querySelectorAll('.needs-validation');
			Array.from(forms).forEach(form => {
				form.addEventListener('submit', event => {
					if (!form.checkValidity()) {
						event.preventDefault();
						event.stopPropagation();
					}
					form.classList.add('was-validated');
				}, false);
			});
		})();
	</script>
</body>
</html>

<?php
} else {
	header('location:login.php');
	exit;
}
?>
