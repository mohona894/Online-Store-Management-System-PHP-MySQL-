<?php
	session_start();

	$user_first_name = $_SESSION['user_first_name'];
	$user_last_name = $_SESSION['user_last_name'];

	if (!empty($user_first_name) && !empty($user_last_name)) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<title>Store Management System | Dashboard</title>

	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />

	<style>
		body {
			background: linear-gradient(135deg, #e9f5ef, #d1e7dd);
			min-height: 100vh;
		}
		.topbar-user {
			font-weight: 600;
			color: #155724;
		}
		.card-action {
			transition: transform 0.2s ease, box-shadow 0.2s ease;
			cursor: pointer;
		}
		.card-action:hover {
			transform: translateY(-6px);
			box-shadow: 0 8px 20px rgba(0,0,0,0.12);
		}
		.card-icon {
			color: #198754;
		}
		.page-header {
			border-bottom: 3px solid #198754;
			margin-bottom: 2rem;
		}
		.breadcrumb {
			background: transparent;
			padding-left: 0;
		}
	</style>
</head>
<body>

	<div class="container bg-light mt-4 rounded shadow-sm p-3">

		<!-- Topbar with User Info and Logout -->
		<div class="d-flex justify-content-between align-items-center border-bottom border-success pb-2 mb-4">
			<div class="h4 text-success mb-0">Store Management System</div>
			<div class="topbar-user">
				<i class="fas fa-user-circle me-2"></i>
				Welcome, <?php echo htmlspecialchars($user_first_name . ' ' . $user_last_name); ?>
				<a href="logout.php" class="btn btn-sm btn-outline-danger ms-3"><i class="fas fa-sign-out-alt"></i> Logout</a>
			</div>
		</div>

		<!-- Breadcrumb -->
		<nav aria-label="breadcrumb" class="mb-4">
			<ol class="breadcrumb">
				<li class="breadcrumb-item active" aria-current="page">Dashboard</li>
			</ol>
		</nav>

		<!-- Page Header -->
		<h2 class="page-header text-success">Quick Actions</h2>

		<!-- Dashboard Grid -->
		<div class="row g-4">

			<!-- Category -->
			<div class="col-6 col-md-3">
				<a href="add_category.php" class="text-decoration-none" data-bs-toggle="tooltip" title="Add New Category">
					<div class="card card-action text-center p-3">
						<i class="fas fa-folder-plus fa-4x card-icon mb-3"></i>
						<h5 class="card-title text-success">Add Category</h5>
					</div>
				</a>
			</div>
			<div class="col-6 col-md-3">
				<a href="list_of_category.php" class="text-decoration-none" data-bs-toggle="tooltip" title="View Categories">
					<div class="card card-action text-center p-3">
						<i class="fas fa-folder-open fa-4x card-icon mb-3"></i>
						<h5 class="card-title text-success">Category List</h5>
					</div>
				</a>
			</div>

			<!-- Product -->
			<div class="col-6 col-md-3">
				<a href="add_product.php" class="text-decoration-none" data-bs-toggle="tooltip" title="Add New Product">
					<div class="card card-action text-center p-3">
						<i class="fas fa-box-open fa-4x card-icon mb-3"></i>
						<h5 class="card-title text-success">Add Product</h5>
					</div>
				</a>
			</div>
			<div class="col-6 col-md-3">
				<a href="list_of_product.php" class="text-decoration-none" data-bs-toggle="tooltip" title="View Products">
					<div class="card card-action text-center p-3">
						<i class="fas fa-stream fa-4x card-icon mb-3"></i>
						<h5 class="card-title text-success">Product List</h5>
					</div>
				</a>
			</div>

			<!-- Store Product -->
			<div class="col-6 col-md-3">
				<a href="add_store_product.php" class="text-decoration-none" data-bs-toggle="tooltip" title="Add Store Product">
					<div class="card card-action text-center p-3">
						<i class="fas fa-warehouse fa-4x card-icon mb-3"></i>
						<h5 class="card-title text-success">Add Store Product</h5>
					</div>
				</a>
			</div>
			<div class="col-6 col-md-3">
				<a href="list_of_entry_product.php" class="text-decoration-none" data-bs-toggle="tooltip" title="View Store Products">
					<div class="card card-action text-center p-3">
						<i class="fas fa-box fa-4x card-icon mb-3"></i>
						<h5 class="card-title text-success">Store Product List</h5>
					</div>
				</a>
			</div>

			<!-- Spend Product -->
			<div class="col-6 col-md-3">
				<a href="add_spend_product.php" class="text-decoration-none" data-bs-toggle="tooltip" title="Add Spend Product">
					<div class="card card-action text-center p-3">
						<i class="fas fa-coins fa-4x card-icon mb-3"></i>
						<h5 class="card-title text-success">Add Spend Product</h5>
					</div>
				</a>
			</div>
			<div class="col-6 col-md-3">
				<a href="list_of_spend_product.php" class="text-decoration-none" data-bs-toggle="tooltip" title="View Spend Products">
					<div class="card card-action text-center p-3">
						<i class="fas fa-wallet fa-4x card-icon mb-3"></i>
						<h5 class="card-title text-success">Spend Product List</h5>
					</div>
				</a>
			</div>

			<!-- Report -->
			<div class="col-6 col-md-3">
				<a href="report.php" class="text-decoration-none" data-bs-toggle="tooltip" title="View Reports">
					<div class="card card-action text-center p-3">
						<i class="fas fa-chart-bar fa-4x card-icon mb-3"></i>
						<h5 class="card-title text-success">Reports</h5>
					</div>
				</a>
			</div>

			<!-- Users -->
			<div class="col-6 col-md-3">
				<a href="add_users.php" class="text-decoration-none" data-bs-toggle="tooltip" title="Add New User">
					<div class="card card-action text-center p-3">
						<i class="fas fa-user-plus fa-4x card-icon mb-3"></i>
						<h5 class="card-title text-success">Add User</h5>
					</div>
				</a>
			</div>
			<div class="col-6 col-md-3">
				<a href="list_of_users.php" class="text-decoration-none" data-bs-toggle="tooltip" title="View Users">
					<div class="card card-action text-center p-3">
						<i class="fas fa-users fa-4x card-icon mb-3"></i>
						<h5 class="card-title text-success">User List</h5>
					</div>
				</a>
			</div>

		</div>

		<div class="mt-5 border-top border-success pt-3 text-center">
			<?php include('bottombar.php'); ?>
		</div>
	</div>

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
	<script>
		var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
		var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
			return new bootstrap.Tooltip(tooltipTriggerEl)
		})
	</script>
</body>
</html>

<?php
	} else {
		header('location:login.php');
		exit;
	}
?>
