<?php
require('connection.php');
session_start();

if(empty($_SESSION['user_first_name']) || empty($_SESSION['user_last_name'])){
    header('Location: login.php');
    exit;
}

if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id'])){
    $product_id = intval($_POST['product_id']);

    $sql = "DELETE FROM product WHERE prdouct_id = $product_id";
    if($conn->query($sql)){
        header('Location: list_of_product.php?msg=deleted');
        exit;
    } else {
        echo "Error deleting product: " . $conn->error;
    }
} else {
    header('Location: list_of_product.php');
    exit;
}
?>
