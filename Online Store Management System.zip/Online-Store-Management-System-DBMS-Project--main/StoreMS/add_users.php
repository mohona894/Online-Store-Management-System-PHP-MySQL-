<?php
require('connection.php');
session_start();

$user_first_name = $_SESSION['user_first_name'] ?? '';
$user_last_name = $_SESSION['user_last_name'] ?? '';

if (!empty($user_first_name) && !empty($user_last_name)) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8" />
	<title>Add User | Store Management</title>
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
	<style>
		body {
			background: #f4f9f4;
			min-height: 100vh;
		}
		.card {
			border-radius: 1rem;
			box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
		}
		.card-header {
			background-color: #198754;
			color: white;
			border-radius: 1rem 1rem 0 0;
			font-weight: bold;
		}
	</style>
</head>
<body>
	<div class="container bg-light mt-4 rounded shadow-sm p-3">
		<!-- Topbar -->
		<div class="border-bottom border-success mb-4">
			<?php include('topbar.php'); ?>
		</div>

		<div class="row">
			<!-- Sidebar -->
			<div class="col-md-3">
				<?php include('leftbar.php'); ?>
			</div>

			<!-- Main Content -->
			<div class="col-md-9 border-start border-success ps-4">
				<div class="card mb-4">
					<div class="card-header">
						<i class="fas fa-user-plus me-2"></i>Add New User
					</div>
					<div class="card-body">
						<?php
						if (isset($_GET['user_first_name'])) {
							$user_first = htmlspecialchars($_GET['user_first_name']);
							$user_last = htmlspecialchars($_GET['user_last_name']);
							$user_email = htmlspecialchars($_GET['user_email']);
							$user_pass = htmlspecialchars($_GET['user_password']);

							$sql = "INSERT INTO users (user_first_name, user_last_name, user_email, user_password) 
									VALUES ('$user_first', '$user_last', '$user_email', '$user_pass')";

							if ($conn->query($sql) === TRUE) {
								echo '<div class="alert alert-success"><i class="fas fa-check-circle me-2"></i>User added successfully!</div>';
							} else {
								echo '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Error: ' . $conn->error . '</div>';
							}
						}
						?>

						<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="GET" class="needs-validation" novalidate>
							<div class="mb-3">
								<label class="form-label">First Name:</label>
								<input type="text" name="user_first_name" class="form-control" required autofocus>
								<div class="invalid-feedback">First name is required.</div>
							</div>

							<div class="mb-3">
								<label class="form-label">Last Name:</label>
								<input type="text" name="user_last_name" class="form-control" required>
								<div class="invalid-feedback">Last name is required.</div>
							</div>

							<div class="mb-3">
								<label class="form-label">Email:</label>
								<input type="email" name="user_email" class="form-control" required>
								<div class="invalid-feedback">Enter a valid email.</div>
							</div>

							<div class="mb-3">
								<label class="form-label">Password:</label>
								<input type="password" name="user_password" class="form-control" required>
								<div class="invalid-feedback">Password is required.</div>
							</div>

							<button type="submit" class="btn btn-success"><i class="fas fa-save me-2"></i>Submit</button>
							<a href="list_of_users.php" class="btn btn-secondary ms-2"><i class="fas fa-users me-2"></i>User List</a>
						</form>
					</div>
				</div>
			</div>
		</div>

		<!-- Bottombar -->
		<div class="mt-4 border-top border-success pt-3 text-center">
			<?php include('bottombar.php'); ?>
		</div>
	</div>

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
	<script>
		(() => {
			'use strict';
			const forms = document.querySelectorAll('.needs-validation');
			Array.from(forms).forEach(form => {
				form.addEventListener('submit', event => {
					if (!form.checkValidity()) {
						event.preventDefault();
						event.stopPropagation();
					}
					form.classList.add('was-validated');
				}, false);
			});
		})();
	</script>
</body>
</html>

<?php
} else {
	header('location:login.php');
	exit;
}
?>
