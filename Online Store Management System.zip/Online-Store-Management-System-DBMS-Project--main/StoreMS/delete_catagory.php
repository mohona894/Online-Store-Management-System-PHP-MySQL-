<?php
require('connection.php');
session_start();

// Check if user is logged in (optional)
if(empty($_SESSION['user_first_name']) || empty($_SESSION['user_last_name'])){
    header('location:login.php');
    exit;
}

if(isset($_GET['id'])){
    $category_id = intval($_GET['id']);

    $sql = "DELETE FROM category WHERE category_id = $category_id";
    if($conn->query($sql)){
        // Success: redirect to category list with success message
        header('Location: list_of_category.php?msg=deleted');
        exit;
    } else {
        echo "Error deleting category: " . $conn->error;
    }
} else {
    header('Location: list_of_category.php');
    exit;
}
?>
