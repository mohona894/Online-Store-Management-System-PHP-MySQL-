<?php
	require('connection.php');
	session_start();

	$user_first_name = $_SESSION['user_first_name'];
	$user_last_name = $_SESSION['user_last_name'];

	if(!empty($user_first_name) && !empty($user_last_name) ){
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<title>List of Users</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
	<style>
		body {
			background-color: #f4f7f8;
		}
		.card {
			border-radius: 0.6rem;
			box-shadow: 0 4px 12px rgba(0,0,0,0.1);
		}
		.table thead th {
			text-align: center;
			vertical-align: middle;
		}
		.table tbody td {
			text-align: center;
			vertical-align: middle;
		}
		.table tbody tr:hover {
			background-color: #e3f2fd;
		}
		.btn-sm {
			padding: 0.25rem 0.5rem;
		}
		.btn-sm i {
			pointer-events: none;
		}
		h3.text-success {
			font-weight: 700;
			letter-spacing: 0.03em;
		}
	</style>
</head>
<body>
	<div class="container my-5 p-4 bg-white rounded shadow-sm">
		<div class="container-foulid border-bottom border-success pb-3 mb-4">
			<?php include('topbar.php'); ?>
		</div>

		<div class="row">
			<div class="col-sm-3 bg-light p-0 m-0 rounded-start shadow-sm">
				<?php include('leftbar.php'); ?>
			</div>

			<div class="col-sm-9 border-start border-success rounded-end">
				<div class="container p-4">
					<h3 class="mb-4 text-success">
						<i class="fas fa-users me-2"></i> List of Users
					</h3>

					<div class="card">
						<div class="card-body p-0">
							<div class="table-responsive">
								<table class="table table-bordered table-striped mb-0">
									<thead class="table-success">
										<tr>
											<th>First Name</th>
											<th>Last Name</th>
											<th>Email</th>
											<th>Actions</th>
										</tr>
									</thead>
									<tbody>
										<?php
											$sql = "SELECT * FROM users";
											$query = $conn->query($sql);

											while($data = mysqli_fetch_assoc($query)){
												$user_id 		 = $data['user_id'];
												$user_first_name = htmlspecialchars($data['user_first_name']);
												$user_last_name  = htmlspecialchars($data['user_last_name']);
												$user_email 	 = htmlspecialchars($data['user_email']);
										?>
										<tr>
											<td><?php echo $user_first_name; ?></td>
											<td><?php echo $user_last_name; ?></td>
											<td><?php echo $user_email; ?></td>
											<td>
												<a href="edit_users.php?id=<?php echo $user_id; ?>" 
												   class="btn btn-primary btn-sm" title="Edit User">
													<i class="fas fa-edit"></i>
												</a>
												<a href="delete_user.php?id=<?php echo $user_id; ?>" 
												   class="btn btn-danger btn-sm" 
												   onclick="return confirm('Are you sure you want to delete this user?');"
												   title="Delete User">
													<i class="fas fa-trash-alt"></i>
												</a>
											</td>
										</tr>
										<?php } ?>
									</tbody>
								</table>
							</div><!-- table-responsive end -->
						</div><!-- card-body end -->
					</div><!-- card end -->
				</div><!-- container end -->
			</div><!-- col-sm-9 end -->
		</div><!-- row end -->

		<div class="container-foulid border-top border-success mt-4 pt-3">
			<?php include('bottombar.php'); ?>
		</div>
	</div><!-- container end -->

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
	}else{
		header('location:login.php');
		exit;
	}
?>
