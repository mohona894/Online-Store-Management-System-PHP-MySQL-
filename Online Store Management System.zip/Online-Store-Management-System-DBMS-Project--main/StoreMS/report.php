<?php
require('connection.php');
session_start();

$user_first_name = $_SESSION['user_first_name'] ?? '';
$user_last_name = $_SESSION['user_last_name'] ?? '';

if (!empty($user_first_name) && !empty($user_last_name)) {
	$sql3 = "SELECT * FROM product";
	$query3 = $conn->query($sql3);

	$data_list = array();
	while ($data3 = mysqli_fetch_assoc($query3)) {
		$prdouct_id = $data3['prdouct_id'];
		$product_name = $data3['product_name'];
		$data_list[$prdouct_id] = $product_name;
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Product Report | Store Management</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
	<style>
		body {
			background: #f9f9f9;
		}
		.card {
			border-radius: 1rem;
			box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
		}
		.card-header {
			background-color: #198754;
			color: white;
			font-weight: bold;
			border-radius: 1rem 1rem 0 0;
		}
		.table thead {
			background-color: #d1e7dd;
		}
	</style>
</head>
<body>
	<div class="container bg-light mt-4 rounded shadow-sm p-3">
		<div class="border-bottom border-success mb-3">
			<?php include('topbar.php'); ?>
		</div>

		<div class="row">
			<div class="col-md-3">
				<?php include('leftbar.php'); ?>
			</div>

			<div class="col-md-9 border-start border-success ps-4">
				<div class="card mb-4">
					<div class="card-header">
						<i class="fas fa-chart-bar me-2"></i>Product Report
					</div>
					<div class="card-body">
						<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="GET" class="mb-4">
							<div class="mb-3">
								<label class="form-label">Select Product:</label>
								<select name="product_name" class="form-select" required>
									<option value="" disabled selected>-- Select Product --</option>
									<?php
										foreach ($data_list as $id => $name) {
											$selected = (isset($_GET['product_name']) && $_GET['product_name'] == $id) ? 'selected' : '';
											echo "<option value='$id' $selected>$name</option>";
										}
									?>
								</select>
							</div>
							<button type="submit" class="btn btn-success"><i class="fas fa-file-alt me-1"></i>Generate Report</button>
						</form>

						<?php
						if (isset($_GET['product_name'])) {
							$product_id = intval($_GET['product_name']);

							// Store Product Report
							echo "<h5 class='text-primary mt-4'>Store Product Report</h5>";

							$sql1 = "SELECT * FROM store_product WHERE store_product_name = $product_id";
							$query1 = $conn->query($sql1);

							$total_store = 0;

							if ($query1->num_rows > 0) {
								echo "<div class='table-responsive'>";
								echo "<table class='table table-bordered table-striped'>";
								echo "<thead><tr><th>Store Date</th><th>Quantity</th></tr></thead><tbody>";
								while ($data1 = mysqli_fetch_assoc($query1)) {
									$store_date = $data1['store_product_entry_date'];
									$quantity = $data1['store_product_quentity'];
									$total_store += $quantity;
									echo "<tr><td>$store_date</td><td>$quantity</td></tr>";
								}
								echo "<tr class='table-success fw-bold'><td>Total</td><td>$total_store</td></tr>";
								echo "</tbody></table></div>";
							} else {
								echo "<p class='text-muted'><i class='fas fa-info-circle me-2'></i>No store product data found.</p>";
							}

							// Spend Product Report
							echo "<h5 class='text-danger mt-4'>Spend Product Report</h5>";

							$sql4 = "SELECT * FROM spend_product WHERE spend_product_name = $product_id";
							$query4 = $conn->query($sql4);

							$total_spend = 0;

							if ($query4->num_rows > 0) {
								echo "<div class='table-responsive'>";
								echo "<table class='table table-bordered table-striped'>";
								echo "<thead><tr><th>Spend Date</th><th>Quantity</th></tr></thead><tbody>";
								while ($data4 = mysqli_fetch_assoc($query4)) {
									$spend_date = $data4['spend_product_entry_date'];
									$quantity = $data4['spend_product_quentity'];
									$total_spend += $quantity;
									echo "<tr><td>$spend_date</td><td>$quantity</td></tr>";
								}
								echo "<tr class='table-danger fw-bold'><td>Total</td><td>$total_spend</td></tr>";
								echo "</tbody></table></div>";
							} else {
								echo "<p class='text-muted'><i class='fas fa-info-circle me-2'></i>No spend product data found.</p>";
							}

							// Final Balance
							$balance = $total_store - $total_spend;
							echo "<h5 class='mt-4'>Remaining Balance: <span class='badge bg-info text-dark'>$balance Units</span></h5>";
						}
						?>
					</div>
				</div>
			</div>
		</div>

		<div class="mt-3 border-top border-success pt-3 text-center">
			<?php include('bottombar.php'); ?>
		</div>
	</div>

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
} else {
	header('location:login.php');
	exit;
}
?>
