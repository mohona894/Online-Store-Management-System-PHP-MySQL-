<?php
	require('connection.php');
	session_start();

	$user_first_name = $_SESSION['user_first_name'];
	$user_last_name = $_SESSION['user_last_name'];

	if (!empty($user_first_name) && !empty($user_last_name)) {
		$product_id = null;
		$product_name = '';
		$product_category = '';
		$product_code = '';
		$product_entry_date = '';
		$success_msg = '';
		$error_msg = '';

		// Fetch product data if id is passed
		if (isset($_GET['id'])) {
			$product_id = intval($_GET['id']);
			$sql = "SELECT * FROM product WHERE prdouct_id = ?";
			$stmt = $conn->prepare($sql);
			$stmt->bind_param('i', $product_id);
			$stmt->execute();
			$result = $stmt->get_result();
			if ($result->num_rows > 0) {
				$data = $result->fetch_assoc();
				$product_name = $data['product_name'];
				$product_category = $data['product_category'];
				$product_code = $data['prdouct_code'];
				$product_entry_date = $data['prdocut_entry_date'];
			} else {
				$error_msg = "Product not found.";
			}
			$stmt->close();
		}

		// Handle form submission via POST
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$product_id = intval($_POST['prdouct_id']);
			$new_product_name = trim($_POST['product_name']);
			$new_product_category = intval($_POST['product_category']);
			$new_product_code = trim($_POST['prdouct_code']);
			$new_product_entry_date = $_POST['prdocut_entry_date'];

			if ($product_id && $new_product_name && $new_product_category && $new_product_code && $new_product_entry_date) {
				$sql_update = "UPDATE product SET product_name=?, product_category=?, prdouct_code=?, prdocut_entry_date=? WHERE prdouct_id=?";
				$stmt = $conn->prepare($sql_update);
				$stmt->bind_param('sissi', $new_product_name, $new_product_category, $new_product_code, $new_product_entry_date, $product_id);

				if ($stmt->execute()) {
					$success_msg = "Product updated successfully!";
					$product_name = $new_product_name;
					$product_category = $new_product_category;
					$product_code = $new_product_code;
					$product_entry_date = $new_product_entry_date;
				} else {
					$error_msg = "Error updating product: " . $conn->error;
				}
				$stmt->close();
			} else {
				$error_msg = "Please fill in all fields.";
			}
		}

		// Get categories for dropdown
		$sql_cat = "SELECT * FROM category ORDER BY category_name ASC";
		$query_cat = $conn->query($sql_cat);
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<title>Edit Product</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
	<style>
		body {
			background-color: #f8fafc;
			font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
		}
		.container-custom {
			padding: 30px 40px;
		}
		h3 {
			font-weight: 700;
			color: #198754;
			margin-bottom: 30px;
		}
		label {
			font-weight: 600;
			color: #333;
		}
		.form-control, .form-select {
			border-radius: 8px;
			box-shadow: none;
			border: 1.5px solid #ced4da;
			transition: border-color 0.3s ease;
		}
		.form-control:focus, .form-select:focus {
			border-color: #198754;
			box-shadow: 0 0 5px rgba(25, 135, 84, 0.4);
		}
		.btn-success {
			min-width: 110px;
			font-weight: 600;
			padding: 10px 18px;
			border-radius: 8px;
		}
		.alert {
			border-radius: 8px;
			font-weight: 600;
		}
	</style>
</head>
<body>
	<div class="container bg-light">
		<div class="container-foulid border-bottom border-success">
			<?php include('topbar.php'); ?>
		</div>

		<div class="container-foulid">
			<div class="row">
				<div class="col-sm-3 bg-light p-0 m-0">
					<?php include('leftbar.php'); ?>
				</div>

				<div class="col-sm-9 border-start border-success">
					<div class="container container-custom">
						<h3><i class="fas fa-box-open me-2"></i>Edit Product</h3>

						<?php if ($success_msg): ?>
							<div class="alert alert-success"><?php echo $success_msg; ?></div>
						<?php endif; ?>

						<?php if ($error_msg): ?>
							<div class="alert alert-danger"><?php echo $error_msg; ?></div>
						<?php endif; ?>

						<?php if ($product_id): ?>
							<form action="edit_product.php?id=<?php echo $product_id; ?>" method="POST" novalidate>
								<div class="mb-3">
									<label for="product_name" class="form-label">Product Name <span class="text-danger">*</span></label>
									<input type="text" id="product_name" name="product_name" class="form-control" value="<?php echo htmlspecialchars($product_name); ?>" required autofocus>
								</div>

								<div class="mb-3">
									<label for="product_category" class="form-label">Product Category <span class="text-danger">*</span></label>
									<select id="product_category" name="product_category" class="form-select" required>
										<option value="">-- Select Category --</option>
										<?php while ($cat = mysqli_fetch_assoc($query_cat)): ?>
											<option value="<?php echo $cat['category_id']; ?>" <?php echo ($cat['category_id'] == $product_category) ? 'selected' : ''; ?>>
												<?php echo htmlspecialchars($cat['category_name']); ?>
											</option>
										<?php endwhile; ?>
									</select>
								</div>

								<div class="mb-3">
									<label for="prdouct_code" class="form-label">Product Code <span class="text-danger">*</span></label>
									<input type="text" id="prdouct_code" name="prdouct_code" class="form-control" value="<?php echo htmlspecialchars($product_code); ?>" required>
								</div>

								<div class="mb-4">
									<label for="prdocut_entry_date" class="form-label">Product Entry Date <span class="text-danger">*</span></label>
									<input type="date" id="prdocut_entry_date" name="prdocut_entry_date" class="form-control" value="<?php echo htmlspecialchars($product_entry_date); ?>" required>
								</div>

								<input type="hidden" name="prdouct_id" value="<?php echo $product_id; ?>" />

								<button type="submit" class="btn btn-success">
									<i class="fas fa-save me-1"></i> Update
								</button>
								<a href="list_of_product.php" class="btn btn-outline-secondary ms-2">Cancel</a>
							</form>
						<?php else: ?>
							<div class="alert alert-warning">No product selected for editing.</div>
						<?php endif; ?>
					</div><!-- container-custom end -->
				</div><!-- col-sm-9 end -->
			</div><!-- row end -->
		</div><!-- container-foulid end -->

		<div class="container-foulid border-top border-success mt-4 pt-3">
			<?php include('bottombar.php'); ?>
		</div>
	</div><!-- container end -->

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
	} else {
		header('location:login.php');
		exit;
	}
?>
