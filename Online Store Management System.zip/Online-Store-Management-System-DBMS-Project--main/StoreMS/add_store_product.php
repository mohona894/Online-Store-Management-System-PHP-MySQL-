<?php
require('connection.php');
require('myfunction.php');
session_start();

$user_first_name = $_SESSION['user_first_name'] ?? '';
$user_last_name  = $_SESSION['user_last_name'] ?? '';

if (!empty($user_first_name) && !empty($user_last_name)) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<title>Add Store Product</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
	<style>
		body {
			background: linear-gradient(to right, #f0fff0, #e6f7f1);
			min-height: 100vh;
		}
		.card {
			border-radius: 1rem;
			box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
		}
		.card-header {
			background-color: #198754;
			color: white;
			font-weight: bold;
			border-radius: 1rem 1rem 0 0;
		}
	</style>
</head>
<body>
	<div class="container bg-light mt-4 rounded shadow-sm p-3">
		<!-- Topbar -->
		<div class="border-bottom border-success mb-4">
			<?php include('topbar.php'); ?>
		</div>

		<div class="row">
			<!-- Sidebar -->
			<div class="col-md-3">
				<?php include('leftbar.php'); ?>
			</div>

			<!-- Main Content -->
			<div class="col-md-9 border-start border-success ps-4">
				<div class="card mb-4">
					<div class="card-header">
						<i class="fas fa-boxes me-2"></i>Add Store Product
					</div>
					<div class="card-body">
						<?php
						if (isset($_GET['store_product_name'])) {
							$store_product_name = $_GET['store_product_name'];
							$store_product_quantity = $_GET['store_product_quentity'];
							$store_product_entry_date = $_GET['store_product_entry_date'];

							if (!empty($store_product_name) && !empty($store_product_quantity) && !empty($store_product_entry_date)) {
								$sql = "INSERT INTO store_product (store_product_name, store_product_quentity, store_product_entry_date) 
										VALUES ('$store_product_name', '$store_product_quantity', '$store_product_entry_date')";

								if ($conn->query($sql) === TRUE) {
									echo '<div class="alert alert-success"><i class="fas fa-check-circle me-2"></i>Data Inserted Successfully!</div>';
								} else {
									echo '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Error: ' . $conn->error . '</div>';
								}
							} else {
								echo '<div class="alert alert-warning"><i class="fas fa-info-circle me-2"></i>Please fill all fields.</div>';
							}
						}
						?>

						<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="GET" class="needs-validation" novalidate>
							<div class="mb-3">
								<label class="form-label">Product:</label>
								<select name="store_product_name" class="form-select" required>
									<option value="" disabled selected>Select Product</option>
									<?php data_list('product', 'prdouct_id', 'product_name'); ?>
								</select>
								<div class="invalid-feedback">Please select a product.</div>
							</div>

							<div class="mb-3">
								<label class="form-label">Product Quantity:</label>
								<input type="number" name="store_product_quentity" class="form-control" min="1" required>
								<div class="invalid-feedback">Enter a valid quantity.</div>
							</div>

							<div class="mb-3">
								<label class="form-label">Store Entry Date:</label>
								<input type="date" name="store_product_entry_date" class="form-control" required>
								<div class="invalid-feedback">Select a date.</div>
							</div>

							<button type="submit" class="btn btn-success"><i class="fas fa-save me-2"></i>Submit</button>
							<a href="list_of_entry_product.php" class="btn btn-secondary ms-2"><i class="fas fa-arrow-left me-2"></i>Back to List</a>
						</form>
					</div>
				</div>
			</div>
		</div>

		<!-- Bottombar -->
		<div class="mt-4 border-top border-success pt-3 text-center">
			<?php include('bottombar.php'); ?>
		</div>
	</div>

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
	<script>
		(() => {
			'use strict';
			const forms = document.querySelectorAll('.needs-validation');
			Array.from(forms).forEach(form => {
				form.addEventListener('submit', event => {
					if (!form.checkValidity()) {
						event.preventDefault();
						event.stopPropagation();
					}
					form.classList.add('was-validated');
				}, false);
			});
		})();
	</script>
</body>
</html>

<?php
} else {
	header('location:login.php');
	exit;
}
?>
