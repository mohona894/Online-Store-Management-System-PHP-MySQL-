<?php
	require('connection.php');
	session_start();

	$user_first_name = $_SESSION['user_first_name'];
	$user_last_name = $_SESSION['user_last_name'];

	if (!empty($user_first_name) && !empty($user_last_name)) {
		$sql1 = "SELECT * FROM product";
		$query1 = $conn->query($sql1);

		$data_list = [];
		while ($data1 = mysqli_fetch_assoc($query1)) {
			$prdouct_id = $data1['prdouct_id'];
			$product_name = $data1['product_name'];
			$data_list[$prdouct_id] = $product_name;
		}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<title>List of Spend Product</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
	<style>
		body {
			background-color: #f8f9fa;
		}
		.card {
			border-radius: 0.6rem;
			box-shadow: 0 4px 12px rgba(0,0,0,0.1);
		}
		.table thead th {
			text-align: center;
			vertical-align: middle;
		}
		.table tbody td {
			vertical-align: middle;
			text-align: center;
		}
		.table tbody tr:hover {
			background-color: #e6f2e6;
		}
		.btn-sm i {
			pointer-events: none;
		}
		h3.text-success {
			font-weight: 700;
			letter-spacing: 0.03em;
		}
	</style>
</head>
<body>
	<div class="container bg-white mt-4 mb-5 p-4 rounded shadow-sm">
		<div class="container-foulid border-bottom border-success pb-3 mb-4">
			<?php include('topbar.php'); ?>
		</div>

		<div class="row">
			<div class="col-sm-3 bg-light p-0 m-0 rounded-start shadow-sm">
				<?php include('leftbar.php'); ?>
			</div>

			<div class="col-sm-9 border-start border-success rounded-end">
				<div class="container p-4">
					<h3 class="mb-4 text-success">
						<i class="fas fa-file-invoice-dollar me-2"></i>List of Spend Product
					</h3>

					<div class="card">
						<div class="card-body p-0">
							<?php
								$sql = "SELECT * FROM spend_product";
								$query = $conn->query($sql);

								if ($query && mysqli_num_rows($query) > 0) {
									echo '<div class="table-responsive">';
									echo '<table class="table table-bordered table-striped mb-0">';
									echo '<thead class="table-success"><tr>
											<th>Product Name</th>
											<th>Quantity</th>
											<th>Entry Date</th>
											<th>Action</th>
										  </tr></thead><tbody>';

									while ($data = mysqli_fetch_assoc($query)) {
										$spend_product_id = $data['spend_product_id'];
										$spend_product_name = $data['spend_product_name'];
										$spend_product_quentity = $data['spend_product_quentity'];
										$spend_product_entry_date = $data['spend_product_entry_date'];

										$product_name_display = isset($data_list[$spend_product_name]) ? htmlspecialchars($data_list[$spend_product_name]) : 'Unknown';

										echo "<tr>
												<td>$product_name_display</td>
												<td>" . htmlspecialchars($spend_product_quentity) . "</td>
												<td>" . htmlspecialchars($spend_product_entry_date) . "</td>
												<td>
													<a href='edit_spend_product.php?id=$spend_product_id' class='btn btn-sm btn-primary' title='Edit'>
														<i class='fas fa-edit'></i>
													</a>
												</td>
											</tr>";
									}

									echo '</tbody></table>';
									echo '</div>';
								} else {
									echo '<div class="alert alert-warning m-3">No spend products found.</div>';
								}
							?>
						</div>
					</div>
				</div><!-- container -->
			</div><!-- col-sm-9 -->
		</div><!-- row -->

		<div class="container-foulid border-top border-success mt-4 pt-3">
			<?php include('bottombar.php'); ?>
		</div>
	</div><!-- container -->

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
	} else {
		header('location:login.php');
		exit;
	}
?>
