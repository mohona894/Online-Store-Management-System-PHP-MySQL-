<?php
$hostname = 'localhost';
$username = 'root';
$password = '';
$dbname   = 'store_db';

$conn = new mysqli($hostname, $username, $password, $dbname);
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}

session_start();
$user_first_name = $_SESSION['user_first_name'] ?? '';
$user_last_name  = $_SESSION['user_last_name'] ?? '';

if (!empty($user_first_name) && !empty($user_last_name)) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<title>Add Category</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
	<style>
		body {
			background: linear-gradient(135deg, #e9f5ef, #d1e7dd);
			min-height: 100vh;
		}
		.card {
			border-radius: 1rem;
			box-shadow: 0 4px 10px rgba(0,0,0,0.1);
		}
		.card-header {
			background-color: #198754;
			color: white;
			font-weight: bold;
			border-radius: 1rem 1rem 0 0;
		}
	</style>
</head>
<body>

<div class="container bg-light mt-4 rounded shadow-sm p-3">
	<!-- Topbar -->
	<div class="border-bottom border-success mb-4">
		<?php include('topbar.php'); ?>
	</div>

	<div class="row">
		<!-- Sidebar -->
		<div class="col-md-3">
			<?php include('leftbar.php'); ?>
		</div>

		<!-- Main Content -->
		<div class="col-md-9 border-start border-success ps-4">
			<div class="card">
				<div class="card-header">
					<i class="fas fa-plus-circle me-2"></i>Add New Category
				</div>
				<div class="card-body">
					<?php
					if (isset($_GET['category_name']) && isset($_GET['category_entrydate'])) {
						$category_name = trim($_GET['category_name']);
						$category_entrydate = $_GET['category_entrydate'];

						if (!empty($category_name) && !empty($category_entrydate)) {
							$sql = "INSERT INTO category (category_name, category_entrydate) 
									VALUES (?, ?)";
							$stmt = $conn->prepare($sql);
							$stmt->bind_param("ss", $category_name, $category_entrydate);

							if ($stmt->execute()) {
								echo '<div class="alert alert-success"><i class="fas fa-check-circle me-2"></i>Category added successfully!</div>';
							} else {
								echo '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle me-2"></i>Failed to add category.</div>';
							}
							$stmt->close();
						} else {
							echo '<div class="alert alert-warning">Please fill in all fields.</div>';
						}
					}
					?>

					<form action="add_category.php" method="GET" class="needs-validation" novalidate>
						<div class="mb-3">
							<label for="category_name" class="form-label">Category Name</label>
							<input type="text" class="form-control" id="category_name" name="category_name" required>
							<div class="invalid-feedback">Please enter a category name.</div>
						</div>

						<div class="mb-3">
							<label for="category_entrydate" class="form-label">Entry Date</label>
							<input type="date" class="form-control" id="category_entrydate" name="category_entrydate" required>
							<div class="invalid-feedback">Please select a date.</div>
						</div>

						<button type="submit" class="btn btn-success"><i class="fas fa-save me-2"></i>Submit</button>
						<a href="list_of_category.php" class="btn btn-secondary ms-2"><i class="fas fa-arrow-left me-2"></i>Back to List</a>
					</form>
				</div>
			</div>
		</div>
	</div>

	<!-- Bottombar -->
	<div class="mt-4 border-top border-success pt-3 text-center">
		<?php include('bottombar.php'); ?>
	</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
	(() => {
		'use strict';
		const forms = document.querySelectorAll('.needs-validation');
		Array.from(forms).forEach(form => {
			form.addEventListener('submit', event => {
				if (!form.checkValidity()) {
					event.preventDefault();
					event.stopPropagation();
				}
				form.classList.add('was-validated');
			}, false);
		});
	})();
</script>
</body>
</html>

<?php
} else {
	header('location:login.php');
	exit;
}
?>
