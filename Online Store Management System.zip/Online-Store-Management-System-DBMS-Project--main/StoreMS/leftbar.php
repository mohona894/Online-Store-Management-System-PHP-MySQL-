<div class="p-3 bg-white rounded shadow-sm">
	<!-- Category Section -->
	<h5 class="bg-success text-white px-3 py-2 rounded">Category</h5>
	<ul class="list-group list-group-flush mb-3">
		<li class="list-group-item">
			<i class="fas fa-folder-plus text-success me-2"></i>
			<a href="add_category.php" class="text-dark text-decoration-none">Add Category</a>
		</li>
		<li class="list-group-item">
			<i class="fas fa-folder-open text-success me-2"></i>
			<a href="list_of_category.php" class="text-dark text-decoration-none">Category List</a>
		</li>
	</ul>

	<!-- Product Section -->
	<h5 class="bg-success text-white px-3 py-2 rounded">Product</h5>
	<ul class="list-group list-group-flush mb-3">
		<li class="list-group-item">
			<i class="fas fa-box-open text-success me-2"></i>
			<a href="add_product.php" class="text-dark text-decoration-none">Add Product</a>
		</li>
		<li class="list-group-item">
			<i class="fas fa-stream text-success me-2"></i>
			<a href="list_of_product.php" class="text-dark text-decoration-none">Product List</a>
		</li>
	</ul>

	<!-- Store Product Section -->
	<h5 class="bg-success text-white px-3 py-2 rounded">Store Product</h5>
	<ul class="list-group list-group-flush mb-3">
		<li class="list-group-item">
			<i class="fas fa-warehouse text-success me-2"></i>
			<a href="add_store_product.php" class="text-dark text-decoration-none">Add Store Product</a>
		</li>
		<li class="list-group-item">
			<i class="fas fa-box text-success me-2"></i>
			<a href="list_of_entry_product.php" class="text-dark text-decoration-none">Store Product List</a>
		</li>
	</ul>

	<!-- Spend Product Section -->
	<h5 class="bg-success text-white px-3 py-2 rounded">Spend Product</h5>
	<ul class="list-group list-group-flush mb-3">
		<li class="list-group-item">
			<i class="fas fa-minus-circle text-success me-2"></i>
			<a href="add_spend_product.php" class="text-dark text-decoration-none">Add Spend Product</a>
		</li>
		<li class="list-group-item">
			<i class="fas fa-list text-success me-2"></i>
			<a href="list_of_spend_product.php" class="text-dark text-decoration-none">Spend Product List</a>
		</li>
	</ul>

	<!-- Report Section -->
	<h5 class="bg-success text-white px-3 py-2 rounded">Report</h5>
	<ul class="list-group list-group-flush mb-3">
		<li class="list-group-item">
			<i class="fas fa-chart-line text-success me-2"></i>
			<a href="report.php" class="text-dark text-decoration-none">Report</a>
		</li>
	</ul>

	<!-- Users Section -->
	<h5 class="bg-success text-white px-3 py-2 rounded">Users</h5>
	<ul class="list-group list-group-flush">
		<li class="list-group-item">
			<i class="fas fa-user-plus text-success me-2"></i>
			<a href="add_users.php" class="text-dark text-decoration-none">Add User</a>
		</li>
		<li class="list-group-item">
			<i class="fas fa-users text-success me-2"></i>
			<a href="list_of_users.php" class="text-dark text-decoration-none">User's List</a>
		</li>
	</ul>
</div>
