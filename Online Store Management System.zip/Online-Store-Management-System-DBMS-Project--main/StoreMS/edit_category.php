<?php
	require('connection.php');
	session_start();

	$user_first_name = $_SESSION['user_first_name'];
	$user_last_name = $_SESSION['user_last_name'];

	if (!empty($user_first_name) && !empty($user_last_name)) {
		$category_id = null;
		$category_name = '';
		$category_entrydate = '';
		$success_msg = '';
		$error_msg = '';

		if (isset($_GET['id'])) {
			$getid = intval($_GET['id']);
			$sql = "SELECT * FROM category WHERE category_id=$getid";
			$query = $conn->query($sql);
			if ($query && $query->num_rows > 0) {
				$data = mysqli_fetch_assoc($query);
				$category_id = $data['category_id'];
				$category_name = $data['category_name'];
				$category_entrydate = $data['category_entrydate'];
			} else {
				$error_msg = 'Category not found.';
			}
		}

		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$category_id = intval($_POST['category_id']);
			$new_category_name = trim($_POST['category_name']);
			$new_category_entrydate = $_POST['category_entrydate'];

			if ($category_id && $new_category_name && $new_category_entrydate) {
				$sql1 = "UPDATE category SET 
							category_name = ?, 
							category_entrydate = ? 
							WHERE category_id = ?";
				$stmt = $conn->prepare($sql1);
				$stmt->bind_param('ssi', $new_category_name, $new_category_entrydate, $category_id);

				if ($stmt->execute()) {
					$success_msg = 'Category updated successfully!';
					$category_name = $new_category_name;
					$category_entrydate = $new_category_entrydate;
				} else {
					$error_msg = 'Update failed: ' . $conn->error;
				}
				$stmt->close();
			} else {
				$error_msg = 'Please fill in all required fields.';
			}
		}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<title>Edit Category</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" />
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
	<style>
		body {
			background-color: #f8fafc;
			font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
		}
		.container-custom {
			padding: 30px 40px;
		}
		h3 {
			font-weight: 700;
			color: #198754;
			margin-bottom: 30px;
		}
		label {
			font-weight: 600;
			color: #333;
		}
		.form-control {
			border-radius: 8px;
			box-shadow: none;
			border: 1.5px solid #ced4da;
			transition: border-color 0.3s ease;
		}
		.form-control:focus {
			border-color: #198754;
			box-shadow: 0 0 5px rgba(25, 135, 84, 0.4);
		}
		.btn-success {
			min-width: 100px;
			font-weight: 600;
			padding: 10px 18px;
			border-radius: 8px;
		}
		.alert {
			border-radius: 8px;
			font-weight: 600;
		}
	</style>
</head>
<body>
	<div class="container bg-light">
		<div class="container-foulid border-bottom border-success">
			<?php include('topbar.php'); ?>
		</div>

		<div class="container-foulid">
			<div class="row">
				<div class="col-sm-3 bg-light p-0 m-0">
					<?php include('leftbar.php'); ?>
				</div>

				<div class="col-sm-9 border-start border-success">
					<div class="container container-custom">
						<h3><i class="fas fa-edit me-2"></i>Edit Category</h3>

						<?php if ($success_msg): ?>
							<div class="alert alert-success"><?php echo $success_msg; ?></div>
						<?php endif; ?>

						<?php if ($error_msg): ?>
							<div class="alert alert-danger"><?php echo $error_msg; ?></div>
						<?php endif; ?>

						<?php if ($category_id): ?>
							<form action="edit_category.php?id=<?php echo $category_id; ?>" method="POST" novalidate>
								<div class="mb-3">
									<label for="category_name" class="form-label">Category Name <span class="text-danger">*</span></label>
									<input type="text" id="category_name" name="category_name" class="form-control" value="<?php echo htmlspecialchars($category_name); ?>" required autofocus>
								</div>

								<div class="mb-4">
									<label for="category_entrydate" class="form-label">Category Entry Date <span class="text-danger">*</span></label>
									<input type="date" id="category_entrydate" name="category_entrydate" class="form-control" value="<?php echo htmlspecialchars($category_entrydate); ?>" required>
								</div>

								<input type="hidden" name="category_id" value="<?php echo $category_id; ?>" />

								<button type="submit" class="btn btn-success">
									<i class="fas fa-save me-1"></i> Update
								</button>
								<a href="list_of_category.php" class="btn btn-outline-secondary ms-2">Cancel</a>
							</form>
						<?php else: ?>
							<div class="alert alert-warning">No category selected for editing.</div>
						<?php endif; ?>
					</div><!-- container-custom end -->
				</div><!-- col-sm-9 end -->
			</div><!-- row end -->
		</div><!-- container-foulid end -->

		<div class="container-foulid border-top border-success mt-4 pt-3">
			<?php include('bottombar.php'); ?>
		</div>
	</div><!-- container end -->

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
	} else {
		header('location:login.php');
		exit;
	}
?>
