<?php
	require('connection.php');
	session_start();

	$user_first_name = $_SESSION['user_first_name'];
	$user_last_name = $_SESSION['user_last_name'];

	if(!empty($user_first_name) && !empty($user_last_name) ){

	$sql1 = "SELECT * FROM category";
	$query1 = $conn->query($sql1);

	$data_list = array();

	while($data1 = mysqli_fetch_assoc($query1)){
		$category_id 	= $data1['category_id'];
		$category_name = $data1['category_name'];

		$data_list[$category_id] = $category_name;
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>List of Product</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
	<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" crossorigin="anonymous"/>
	<style>
		body {
			background-color: #f9fafb;
		}
		.table thead th {
			vertical-align: middle;
			text-align: center;
		}
		.table tbody td {
			vertical-align: middle;
		}
		.card {
			box-shadow: 0 4px 8px rgba(0,0,0,0.05);
			border-radius: 0.5rem;
		}
		.action-btns a, .action-btns button {
			min-width: 70px;
			text-align: center;
			margin-right: 5px;
		}
		form {
			display: inline;
		}
	</style>
</head>
<body>
	<div class="container bg-white mt-4 mb-5 p-4 rounded shadow-sm">
		<div class="container-fluid border-bottom border-success pb-3 mb-4">
			<?php include('topbar.php'); ?>
		</div>

		<div class="row">
			<div class="col-sm-3 bg-light p-0 m-0 rounded-start shadow-sm">
				<?php include('leftbar.php'); ?>
			</div>

			<div class="col-sm-9 border-start border-success rounded-end">
				<div class="container p-4">
					<h3 class="mb-4 text-success"><i class="fas fa-box-open me-2"></i>Product List</h3>

					<div class="card">
						<div class="card-body p-0">
							<div class="table-responsive">
								<table class="table table-bordered table-striped mb-0">
									<thead class="table-success">
										<tr>
											<th>Product Name</th>
											<th>Category</th>
											<th>Code</th>
											<th class="text-center">Action</th>
										</tr>
									</thead>
									<tbody>
										<?php
											$sql = "SELECT * FROM product";
											$query = $conn->query($sql);

											if ($query->num_rows > 0) {
												while($data = mysqli_fetch_assoc($query)){
													$prdouct_id 		= $data['prdouct_id'];
													$product_name 		= htmlspecialchars($data['product_name']);
													$product_category 	= $data['product_category'];
													$prdouct_code 		= htmlspecialchars($data['prdouct_code']);

													$category_name = isset($data_list[$product_category]) ? htmlspecialchars($data_list[$product_category]) : "Unknown";

													echo "<tr>
															<td>$product_name</td>
															<td>$category_name</td>
															<td>$prdouct_code</td>
															<td class='text-center action-btns'>
																<a href='edit_product.php?id=$prdouct_id' class='btn btn-primary btn-sm'>
																	<i class='fas fa-edit'></i> Edit
																</a>

																<form method='POST' action='delete_product.php' onsubmit=\"return confirm('Are you sure you want to delete this product?');\">
																	<input type='hidden' name='product_id' value='$prdouct_id' />
																	<button type='submit' class='btn btn-danger btn-sm'>
																		<i class='fas fa-trash-alt'></i> Delete
																	</button>
																</form>
															</td>
														</tr>";
												}
											} else {
												echo "<tr><td colspan='4' class='text-center text-muted py-3'>No products found.</td></tr>";
											}
										?>
									</tbody>
								</table>
							</div><!-- table-responsive -->
						</div><!-- card-body -->
					</div><!-- card -->
				</div><!-- container -->
			</div><!-- col-sm-9 -->
		</div><!-- row -->

		<div class="container-fluid border-top border-success mt-4 pt-3">
			<?php include('bottombar.php'); ?>
		</div>
	</div><!-- main container -->

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
</body>
</html>

<?php
	}else{
		header('location:login.php');
		exit;
	}
?>
